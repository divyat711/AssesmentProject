Pre conditions / softwares:
IDE : Eclipse should be installed
Java needs to be installed.
TestNG, maven should be installed in ecilipse through Help--> Eclipse Marketplace

Project configuration:
Import project as Maven with pom.xml

Execution:
 open testNG.xml which is in test/resources package.
 Right click on testng file and Run tests as testNG.suite
 
Reports:
 Can find the reports in either emailable-report.html or index.html under test-output folder