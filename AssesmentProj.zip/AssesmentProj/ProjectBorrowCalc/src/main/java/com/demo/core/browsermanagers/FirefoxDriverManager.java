package com.demo.core.browsermanagers;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import com.demo.core.DriverManager;

import io.github.bonigarcia.wdm.WebDriverManager;


public class FirefoxDriverManager extends DriverManager {

	/** Method to create driver instance of firefox */
	@Override
	protected void createDriver() {
		WebDriverManager.firefoxdriver().setup();

		FirefoxOptions options = new FirefoxOptions();
		options.setAcceptInsecureCerts(true);
		this.driver = new FirefoxDriver(options);
	}
}
