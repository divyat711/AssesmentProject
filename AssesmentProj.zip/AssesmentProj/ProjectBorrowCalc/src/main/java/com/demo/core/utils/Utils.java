package com.demo.core.utils;

import java.io.InputStream;
import java.util.Properties;

public class Utils {
	private static String configPropertyPath = "/config.properties";
	private static Properties props = null;

	/**
	 * Read values from properties file
	 *
	 * @param propertyName Property key to read value for
	 * @return Return read value of property key
	 */
	public static String getPropertyValue(String propertyName) {
		try {
			props = getAllProperty(configPropertyPath);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return props.getProperty(propertyName);
	}

	/**
	 * Load The Properties files into project
	 *
	 * @param propertyFileName Property File name
	 * @return Returns the all the loaded files
	 * @throws Exception
	 */
	public static Properties getAllProperty(String... fileNames) throws Exception {
		Utils portalUtils = new Utils();
		if (props == null) {
			props = new Properties();
			for (String fileName : fileNames) {
				InputStream file = portalUtils.getFileFromResources(fileName);
				if (file != null) {
					props.load(file);
					System.out.println("File with name " + fileName + " Loaded");
				} else {
					System.out.println("No File with name " + fileName + " Loaded");
				}
			}
		}
		return props;
	}

	/**
	 * @param propertyFileName gets file from classpath, resources folder
	 * @return returns the File object
	 */
	public InputStream getFileFromResources(String fileName) {
		return getClass().getResourceAsStream(fileName);

	}
	
	
	
}
