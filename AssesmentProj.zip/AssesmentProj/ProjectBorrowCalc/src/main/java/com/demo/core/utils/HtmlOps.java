package com.demo.core.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/** This Class is used to do the Selenium operations */

/**
 * implicit timeouts of driver are set in setup plug in
 *
 */
public class HtmlOps {
	static long ajax_pageload_time = 15; // Seconds for page load.
	public static final int DEFAULT_UIELEMENT_WAIT_TIME = 15;
	protected static final int WAIT_TIME = 45; // in seconds
	private static final long WAIT_POLL_TIME = 5000; // in milliseconds
	public static WebDriver driver;
	
	public void setInputField(String value, WebElement element) {
		try {
			
			element.sendKeys(value);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	public void click(WebElement element) {
		try {
			waitForElementVisibility(20,element);
			element.click();
		} catch (StaleElementReferenceException sere) {
			// simply retry finding the element in the refreshed DOM
			element.click();
		} catch (ElementClickInterceptedException interceptedEx) {
			scrollingToElementofAPage(element);
			element.click();
		} catch (TimeoutException toe) {
			System.err.println("Element identified by " + element.toString() + " was not clickable after 10 seconds");
			throw toe;
		}
	}

	

	/**
	 * This method will return the Input field value
	 *
	 * @param element Webelement of input field
	 */
	public String getInputFieldValue(WebElement element) throws ElementNotVisibleException {
		return element.getAttribute("value");
	}

	/**
	 * This method will return the text value for the given element
	 *
	 * @param element Element to get text from
	 * @return Text from element
	 * @throws ElementNotVisibleException
	 */
	public String getElementText(WebElement element) throws ElementNotVisibleException {
		waitForElementVisibility(20, element);
		String val = element.getText();
		if (null != val && !val.isEmpty()) {
			return val;
		}
		return element.getAttribute("value");
	}



	public void waitForElementVisibility(long secondsToWait, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, secondsToWait);
		if (wait.until(ExpectedConditions.visibilityOfAllElements(element)) != null)
			System.out.println("element is visible" + element.toString().substring(element.toString().indexOf("->")));
		else
			System.out.println("element is not visible" + element.toString().substring(element.toString().indexOf("->")));
	}
	
	public void waitForTextToBePresentInElement(long secondsToWait, WebElement element, String text) {
		WebDriverWait wait = new WebDriverWait(driver, secondsToWait);
		if (wait.until(ExpectedConditions.textToBePresentInElement(element, text)) != null)
			System.out.println("element is visible" + element.toString().substring(element.toString().indexOf("->")));
		else
			System.out.println("element is not visible" + element.toString().substring(element.toString().indexOf("->")));
	}
	
	/**
	 * Scroll to specific element in web page
	 *
	 * @param element
	 */
	public void scrollingToElementofAPage(WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
	}
	
	
	
}
