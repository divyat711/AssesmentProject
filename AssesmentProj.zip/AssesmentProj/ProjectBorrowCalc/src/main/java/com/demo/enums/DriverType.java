package com.demo.enums;
public enum DriverType {
	/** DRIVER TYPES */
	CHROME, FIREFOX
}
