package com.demo.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.demo.core.utils.HtmlOps;

public class CalculatorToolsPage extends HtmlOps {
	 
	public CalculatorToolsPage.CalcualtorPageObjects calPageObj;
	public String estimatedBorrowedValue="$501,000";
	
	public CalculatorToolsPage() {
		calPageObj = new CalculatorToolsPage.CalcualtorPageObjects();
		PageFactory.initElements(driver, calPageObj);
	}	
	
	public void fillAndClickForm(String annualIncome, String annualOtherIncome, String monthlyLivingExpenses,
			String homeLoanMonthlyRepayments, String otherLoanMonthlyPayments, String otherMonthlyCommitments,
			String totalCreditCardLimit) {	
		
		setInputField(annualIncome, calPageObj.annualIncome);
		setInputField(annualOtherIncome, calPageObj.annualOtherIncome);
		setInputField(monthlyLivingExpenses, calPageObj.monthlyLivingExpenses);
		setInputField(homeLoanMonthlyRepayments, calPageObj.homeLoanMonthlyRepayments);
		setInputField(otherLoanMonthlyPayments, calPageObj.otherLoanMonthlyPayments);
		setInputField(otherMonthlyCommitments, calPageObj.otherMonthlyCommitments);
		setInputField(totalCreditCardLimit, calPageObj.totalCreditCardLimit);
		click(calPageObj.calBorrow_btn);
		waitForTextToBePresentInElement(DEFAULT_UIELEMENT_WAIT_TIME, calPageObj.borrowResultTextAmount, estimatedBorrowedValue);
	}
	
	public String getBorrowedValue()
	{
		String borrowedValue= getElementText(calPageObj.borrowResultTextAmount);
		return borrowedValue;
	}
	
	public void enterMonthlyExp(String monthlyLivingExpenses) {				
		setInputField(monthlyLivingExpenses, calPageObj.monthlyLivingExpenses);		
		click(calPageObj.calBorrow_btn);
	}

	public String getBorrowingErrorMessage()
	{
		String errorMessage= getElementText(calPageObj.borrowErrorText);
		return errorMessage;
	}
	
	public void verifyStartoverFunctionality() {							
		click(calPageObj.startOver_btn);
		Assert.assertEquals("0", getInputFieldValue(calPageObj.annualIncome), "Annaul income Field is not empty");
		Assert.assertEquals("0", getInputFieldValue(calPageObj.annualOtherIncome), "Annual other income Field is not empty");
		Assert.assertEquals("0", getInputFieldValue(calPageObj.monthlyLivingExpenses), "Monthly living exp Field is not empty");
		Assert.assertEquals("0", getInputFieldValue(calPageObj.homeLoanMonthlyRepayments), "Home loan monthly repayments Field is not empty");
		Assert.assertEquals("0", getInputFieldValue(calPageObj.otherLoanMonthlyPayments), "Other loan monthly payments Field is not empty");
		Assert.assertEquals("0", getInputFieldValue(calPageObj.otherMonthlyCommitments), "Other monthly commitments Field is not empty");
		Assert.assertEquals("0", getInputFieldValue(calPageObj.totalCreditCardLimit), "Total creditcard limit Field is not empty");		
	}
	
	private class CalcualtorPageObjects {
		
		@FindBy(xpath = "//input[@aria-labelledby='q2q1']")
		private WebElement annualIncome;
		
		@FindBy(xpath = "//input[@aria-labelledby='q2q2']")
		private WebElement annualOtherIncome;
		
		@FindBy(xpath = "//input[@id='expenses']")
		private WebElement monthlyLivingExpenses;
		
		@FindBy(xpath = "//input[@id = 'homeloans']")
		private WebElement homeLoanMonthlyRepayments;
		
		@FindBy(xpath = "//input[@id = 'otherloans']")
		private WebElement otherLoanMonthlyPayments;
		
		@FindBy(xpath = "//input[@aria-labelledby = 'q3q4']")
		private WebElement otherMonthlyCommitments;
		
		@FindBy(xpath = "//input[@id = 'credit']")
		private WebElement totalCreditCardLimit;
		
		@FindBy(xpath = "//button[@id = 'btnBorrowCalculater']")
		private WebElement calBorrow_btn;
		
		@FindBy(xpath = "//div[@class='result__restart']//button")
		private WebElement startOver_btn;
		
		@FindBy(xpath = "//div[@class='borrow__error__text']")
		private WebElement borrowErrorText;
		
		@FindBy(xpath="//span[@id='borrowResultTextAmount']")
		private WebElement borrowResultTextAmount;
		
	}
}
