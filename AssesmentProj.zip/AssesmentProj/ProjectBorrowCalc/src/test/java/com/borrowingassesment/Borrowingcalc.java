package com.borrowingassesment;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.demo.core.PortalTestBase;
import com.demo.pages.CalculatorToolsPage;

public class Borrowingcalc extends PortalTestBase {
	
	public String annincome="80000";
	public String annualOtherIncome="10000";
	public String monthlyLivingExpenses="500";
	public String homeLoanMonthlyRepayments="0";
	public String otherLoanMonthlyPayments="100";
	public String otherMonthlyCommitments="0";
	public String totalCreditCardLimit="10000";
	
	public String estimatedBorrowedValue="$501,000";
	public String borrowerErrorMessage = "Based on the details you've entered, we're unable to give you an estimate of your borrowing power with this calculator. For questions, call us on 1800 035 500.";

	@Test(testName="EstimateBorrowedValue")
	public void testEstimateBorrowedValue() {
		CalculatorToolsPage calc = new CalculatorToolsPage();
		calc.fillAndClickForm(annincome, annualOtherIncome, monthlyLivingExpenses, homeLoanMonthlyRepayments, otherLoanMonthlyPayments, otherMonthlyCommitments, totalCreditCardLimit);
		Assert.assertEquals(estimatedBorrowedValue, calc.getBorrowedValue(), "Value is not matched");
	}
	
	@Test(testName="BorrowerErrorMessage")
	public void testBorrowerErrorMessage() {
		CalculatorToolsPage calc = new CalculatorToolsPage();
		calc.enterMonthlyExp(monthlyLivingExpenses);
		Assert.assertEquals(borrowerErrorMessage, calc.getBorrowingErrorMessage(), "Error message is not displaying");
	}
	
	@Test(testName="StartOVerFunctionality")
	public void testStartoverFunctionality() {
		CalculatorToolsPage calc = new CalculatorToolsPage();
		calc.fillAndClickForm(annincome, annualOtherIncome, monthlyLivingExpenses, homeLoanMonthlyRepayments, otherLoanMonthlyPayments, otherMonthlyCommitments, totalCreditCardLimit);		
		calc.verifyStartoverFunctionality();
	}
}
